import os
import random
import threading
import time
import json

from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QPushButton, QLabel, QMessageBox,
    QLineEdit, QFormLayout, QRadioButton, QButtonGroup
)
from wechat_auto_tools import ListenObjectType, MessageProcessorType


class SessionListenWindow(QMainWindow):
    def __init__(self, parent=None, wechat=None):
        super().__init__(parent)
        self.setWindowTitle("全局消息监听")
        self.resize(400, 400)
        self.wechat = wechat
        main_widget = QWidget()
        layout = QVBoxLayout(main_widget)

        form_layout = QFormLayout()

        # 无需监听对象
        self.exclude_input = QLineEdit()
        form_layout.addRow("无需监听对象:", self.exclude_input)
        self.exclude_input.setPlaceholderText("请输入不需要监听的对象名称，用英文逗号分隔")

        # 消息处理器类型（单选按钮）
        self.keyword_radio = QRadioButton("关键字回复")
        self.ai_radio = QRadioButton("AI 回复")
        self.keyword_radio.setChecked(True)  # 默认选中关键字回复
        self.message_type_group = QButtonGroup(self)
        self.message_type_group.addButton(self.keyword_radio, 0)
        self.message_type_group.addButton(self.ai_radio, 1)

        type_layout = QHBoxLayout()
        type_layout.addWidget(self.keyword_radio)
        type_layout.addWidget(self.ai_radio)
        form_layout.addRow("消息处理器类型:", type_layout)

        # 消息处理器配置
        self.config_input = QLineEdit()
        form_layout.addRow("消息处理器配置:", self.config_input)
        self.config_input.setPlaceholderText("必填：消息处理器的参数配置")

        # 默认回复消息
        self.default_reply_input = QLineEdit()
        form_layout.addRow("默认回复消息:", self.default_reply_input)
        self.default_reply_input.setPlaceholderText("当消息处理器无法成功处理消息时，会采用该回复")

        layout.addLayout(form_layout)

        # --- 开始按钮 ---
        btn_layout = QHBoxLayout()
        self.start_btn = QPushButton("开始全局监听")
        self.start_btn.clicked.connect(self.start_listen_action)
        btn_layout.addStretch()
        btn_layout.addWidget(self.start_btn)
        layout.addLayout(btn_layout)

        self.setCentralWidget(main_widget)

    def start_listen_action(self):
        # 获取无需监听对象
        exclude_set = {t.strip() for t in self.exclude_input.text().split(",") if t.strip()}

        # 获取消息处理器类型
        message_type_id = self.message_type_group.checkedId()

        # 获取配置和默认消息
        config = self.config_input.text().strip()
        default_reply = self.default_reply_input.text().strip()

        # 校验必填
        if not config:
            QMessageBox.warning(self, "提示", "消息处理器配置不能为空")
            return

        processor_type = None
        if message_type_id == 0:
            processor_type = MessageProcessorType.KEYWORDS
            # 将 config_edit 转为字典
            try:
                config_dict = json.loads(config)  # 把 JSON 字符串转成 dict
            except json.JSONDecodeError as e:
                QMessageBox.warning(self, "错误", f"处理器配置不是合法的 JSON 格式: {e}")
                return
            # 初始化关键字回复字典库
            self.wechat.init_keyword_reply_dbbase("session", config_dict)
        else:
            processor_type = MessageProcessorType.AI
            if not os.path.isfile(config):
                QMessageBox.warning(self, "错误", f"处理器配置文件不存在: {config}")
                return
            self.wechat.load_custom_ai_reply_interface_by_file_path("session", config)

        # 🚀 用后台线程启动整个监听逻辑
        t = threading.Thread(target=self.wechat.start_session_listen(processor_type, exclude_set, default_reply),
                             daemon=True)
        QMessageBox.information(self, "开始监听", "全局监听期间，请不要关闭或最小化微信窗口")
        t.start()
