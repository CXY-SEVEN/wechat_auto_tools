import random
import time

from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QPushButton, QLabel, QAction, QMessageBox, QMenuBar,
    QLineEdit, QFormLayout, QRadioButton, QCheckBox, QButtonGroup
)


class AddFriendWindow(QMainWindow):
    def __init__(self, parent=None, wechat=None):
        super().__init__(parent)
        self.setWindowTitle("自动添加好友")
        self.resize(400, 400)
        self.wechat = wechat
        main_widget = QWidget()
        layout = QVBoxLayout(main_widget)

        form_layout = QFormLayout()

        self.phone_input = QLineEdit()
        form_layout.addRow("手机号/微信号:", self.phone_input)
        self.phone_input.setPlaceholderText("多个手机号或微信号，请用逗号分隔")

        self.message_input = QLineEdit()
        form_layout.addRow("申请消息:", self.message_input)
        self.message_input.setPlaceholderText("加好友时的申请消息，可以不输入")

        self.remark_input = QLineEdit()
        form_layout.addRow("备注:", self.remark_input)
        self.remark_input.setPlaceholderText("加好友时设置的备注，可以不输入")

        self.tags_input = QLineEdit()
        self.tags_input.setPlaceholderText("多个标签用逗号分隔")
        form_layout.addRow("标签:", self.tags_input)

        # --- 朋友圈权限 (单选框) ---
        self.permission_group = QButtonGroup(self)
        self.radio_all = QRadioButton("聊天、朋友圈、微信运动")
        self.radio_chat = QRadioButton("仅聊天")
        self.radio_all.setChecked(True)
        self.permission_group.addButton(self.radio_all, 0)
        self.permission_group.addButton(self.radio_chat, 1)

        permission_layout = QHBoxLayout()
        permission_layout.addWidget(self.radio_all)
        permission_layout.addWidget(self.radio_chat)
        form_layout.addRow("朋友圈权限:", permission_layout)

        # --- 朋友圈状态 (复选框) ---
        self.check_no_see = QCheckBox("不让他（她）看")
        self.check_no_watch = QCheckBox("不看他（她）")

        status_layout = QHBoxLayout()
        status_layout.addWidget(self.check_no_see)
        status_layout.addWidget(self.check_no_watch)
        form_layout.addRow("朋友圈状态:", status_layout)

        layout.addLayout(form_layout)

        # --- 开始按钮 ---
        btn_layout = QHBoxLayout()
        self.start_btn = QPushButton("开始自动加好友")
        self.start_btn.clicked.connect(self.start_add_friend_action)
        btn_layout.addStretch()
        btn_layout.addWidget(self.start_btn)
        layout.addLayout(btn_layout)

        self.setCentralWidget(main_widget)

    def start_add_friend_action(self):
        # 计算朋友圈权限
        permission_value = self.permission_group.checkedId()  # 0 或 1

        # 计算朋友圈状态
        status_value = 0
        if self.check_no_see.isChecked():
            status_value += 1
        if self.check_no_watch.isChecked():
            status_value += 2

        if self.phone_input.text() == '':
            QMessageBox.information(self, "错误", "必须输入手机号或微信号")
            return

        tags_set = {t.strip() for t in self.tags_input.text().split(",") if t.strip()}
        phone_list = [t.strip() for t in self.phone_input.text().split(",") if t.strip()]

        results = []  # 存放执行结果

        for phone in phone_list:
            try:
                self.wechat.add_friend(
                    phone=phone,
                    message=self.message_input.text(),
                    remarks=self.remark_input.text(),
                    tags=tags_set,
                    friend_permission=permission_value,
                    friend_status=status_value
                )
                results.append(f"{phone}: 添加成功")
                delay = random.uniform(3, 6)
                time.sleep(delay)
            except Exception as e:
                e_message = str(e)
                if e_message == "运行过多，触发微信限制，为保障您的账号安全，请间隔几天再使用该功能":
                    results.append(f"{phone}: {e_message}")
                    print(e_message)
                    break  # 触发限制，立即停止循环
                elif e_message == f"无法找到该用户：{phone}":
                    results.append(f"{phone}: 用户不存在")
                elif e_message == "对方已经是好友了，无需重复添加":
                    results.append(f"{phone}: 已经是好友，无需重复添加")
                else:
                    results.append(f"{phone}: 未知错误 -> {e_message}")

        # 拼接结果展示
        summary = "\n".join(results)
        QMessageBox.information(self, "执行结果", summary)
