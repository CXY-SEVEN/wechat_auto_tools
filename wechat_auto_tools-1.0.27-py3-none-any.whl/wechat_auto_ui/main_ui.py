import sys
from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QPushButton, QLabel, QAction, QMessageBox, QMenuBar,
    QLineEdit, QFormLayout, QRadioButton, QCheckBox, QButtonGroup
)
from PyQt5.QtCore import Qt, QRect
from PyQt5.QtGui import QCursor
from wechat_auto_tools import WechatAutoTools
from wechat_auto_ui.add_friend_ui import AddFriendWindow
from wechat_auto_ui.message_listen_ui import MessageListenWindow
from wechat_auto_ui.session_listen_ui import SessionListenWindow


class CustomTitleBar(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.parent = parent

        self.setFixedHeight(40)
        self.setMouseTracking(True)

        self.setStyleSheet("""
            CustomTitleBar {
                background-color: #e6eef9;
                border-top-left-radius: 15px;
                border-top-right-radius: 15px;
            }
            QLabel {
                font-size: 14px;
                font-weight: bold;
                color: #333;
            }
            QPushButton {
                border: none;
                background: transparent;
                padding: 5px 12px;
                border-radius: 6px;
            }
            QPushButton:hover {
                background-color: #c9dffc;
            }
        """)

        layout = QHBoxLayout(self)
        layout.setContentsMargins(15, 0, 15, 0)
        layout.setSpacing(10)

        self.title = QLabel("Wechat自动化工具箱", self)
        layout.addWidget(self.title, alignment=Qt.AlignVCenter)

        layout.addStretch()

        self.min_btn = QPushButton("—", self)
        self.min_btn.setFixedSize(30, 24)
        self.min_btn.clicked.connect(self.minimize)
        layout.addWidget(self.min_btn, alignment=Qt.AlignVCenter)

        self.max_btn = QPushButton("□", self)
        self.max_btn.setFixedSize(30, 24)
        self.max_btn.clicked.connect(self.maximize_restore)
        layout.addWidget(self.max_btn, alignment=Qt.AlignVCenter)

        self.close_btn = QPushButton("✕", self)
        self.close_btn.setFixedSize(30, 24)
        self.close_btn.clicked.connect(self.close)
        layout.addWidget(self.close_btn, alignment=Qt.AlignVCenter)

    def minimize(self):
        self.parent.showMinimized()

    def maximize_restore(self):
        if self.parent.isMaximized():
            self.parent.showNormal()
            self.max_btn.setText("□")
        else:
            self.parent.showMaximized()
            self.max_btn.setText("❐")

    def close(self):
        self.parent.close()

    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton and not self.parent.isMaximized():
            self.drag_pos = event.globalPos() - self.parent.frameGeometry().topLeft()
            event.accept()

    def mouseMoveEvent(self, event):
        if event.buttons() == Qt.LeftButton and not self.parent.isMaximized():
            self.parent.move(event.globalPos() - self.drag_pos)
            event.accept()


class WechatToolbox(QMainWindow):
    MARGIN = 8

    def __init__(self):
        super().__init__()
        self.wechat = WechatAutoTools()
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.WindowSystemMenuHint | Qt.WindowMinMaxButtonsHint)
        self.resize(600, 400)

        self.setMouseTracking(True)

        main_widget = QWidget()
        main_widget.setMouseTracking(True)
        main_layout = QVBoxLayout(main_widget)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)

        self.title_bar = CustomTitleBar(self)
        main_layout.addWidget(self.title_bar)

        content = QWidget()
        content.setObjectName("content")
        content.setMouseTracking(True)
        content.setStyleSheet("""
            QWidget#content {
                background-color: #f7f9fc;
                border-radius: 15px;
            }
            QMenuBar {
                background-color: #e6eef9;
                border-radius: 10px;
                font-size: 14px;
                padding: 4px;
            }
        """)
        content_layout = QVBoxLayout(content)

        menubar = QMenuBar(self)
        content_layout.addWidget(menubar)

        function_menu = menubar.addMenu("功能")
        send_msg_action = QAction("定时发送消息", self)
        send_msg_action.triggered.connect(self.send_message)
        function_menu.addAction(send_msg_action)

        add_friend_action = QAction("自动添加好友", self)
        add_friend_action.triggered.connect(self.open_add_friend_window)
        function_menu.addAction(add_friend_action)

        message_listen_action = QAction("群/好友消息监听", self)
        message_listen_action.triggered.connect(self.open_message_listen_window)
        function_menu.addAction(message_listen_action)

        session_listen_action = QAction("全局消息监听", self)
        session_listen_action.triggered.connect(self.open_session_listen_window)
        function_menu.addAction(session_listen_action)

        intro_menu = menubar.addMenu("工具箱介绍")
        func_intro_action = QAction("功能介绍", self)
        func_intro_action.triggered.connect(self.show_function_intro)
        intro_menu.addAction(func_intro_action)

        author_intro_action = QAction("作者介绍", self)
        author_intro_action.triggered.connect(self.show_author_intro)
        intro_menu.addAction(author_intro_action)

        main_layout.addWidget(content)
        self.setCentralWidget(main_widget)

        self.resizing = False
        self.resize_dir = None

    def send_message(self):
        QMessageBox.information(self, "定时发送消息", "这里是定时发送消息的功能。")

    def open_add_friend_window(self):
        self.add_friend_window = AddFriendWindow(self, self.wechat)
        self.add_friend_window.show()

    def open_message_listen_window(self):
        self.message_listen_window = MessageListenWindow(self, self.wechat)
        self.message_listen_window.show()

    def open_session_listen_window(self):
        self.session_listen_window = SessionListenWindow(self, self.wechat)
        self.session_listen_window.show()

    def show_function_intro(self):
        QMessageBox.information(self, "功能介绍", "这是一个微信自动化工具箱，提供消息发送、好友添加、群/好友消息监听、全局监听功能。")

    def show_author_intro(self):
        QMessageBox.information(self, "作者介绍", "作者：CXY-SEVEN\n联系方式：3128568434@qq.com")

    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton and self.resize_dir:
            self.resizing = True
            self.drag_pos = event.globalPos()
            self.start_geom = self.geometry()

    def mouseReleaseEvent(self, event):
        self.resizing = False
        self.resize_dir = None
        self.setCursor(Qt.ArrowCursor)

    def mouseMoveEvent(self, event):
        if self.resizing:
            diff = event.globalPos() - self.drag_pos
            rect = QRect(self.start_geom)

            if "left" in self.resize_dir:
                rect.setLeft(rect.left() + diff.x())
            if "right" in self.resize_dir:
                rect.setRight(rect.right() + diff.x())
            if "top" in self.resize_dir:
                rect.setTop(rect.top() + diff.y())
            if "bottom" in self.resize_dir:
                rect.setBottom(rect.bottom() + diff.y())

            if rect.width() >= 400 and rect.height() >= 300:
                self.setGeometry(rect)
        else:
            pos = self.mapFromGlobal(QCursor.pos())
            x, y, w, h = pos.x(), pos.y(), self.width(), self.height()
            margin = self.MARGIN
            self.resize_dir = None

            if x <= margin and y <= margin:
                self.resize_dir = "top_left"
                self.setCursor(Qt.SizeFDiagCursor)
            elif x >= w - margin and y <= margin:
                self.resize_dir = "top_right"
                self.setCursor(Qt.SizeBDiagCursor)
            elif x <= margin and y >= h - margin:
                self.resize_dir = "bottom_left"
                self.setCursor(Qt.SizeBDiagCursor)
            elif x >= w - margin and y >= h - margin:
                self.resize_dir = "bottom_right"
                self.setCursor(Qt.SizeFDiagCursor)
            elif x <= margin:
                self.resize_dir = "left"
                self.setCursor(Qt.SizeHorCursor)
            elif x >= w - margin:
                self.resize_dir = "right"
                self.setCursor(Qt.SizeHorCursor)
            elif y <= margin:
                self.resize_dir = "top"
                self.setCursor(Qt.SizeVerCursor)
            elif y >= h - margin:
                self.resize_dir = "bottom"
                self.setCursor(Qt.SizeVerCursor)
            else:
                self.setCursor(Qt.ArrowCursor)


if __name__ == "__main__":
    app = QApplication(sys.argv)
    app.setAttribute(Qt.AA_EnableHighDpiScaling)
    app.setAttribute(Qt.AA_UseHighDpiPixmaps)

    window = WechatToolbox()
    window.show()
    sys.exit(app.exec_())
