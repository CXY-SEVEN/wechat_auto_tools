import json
import os
import threading


from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QPushButton, QMessageBox, QTableWidget, QLineEdit, QComboBox
)
from wechat_auto_tools import ListenObjectType, MessageProcessorType

CONFIG_FILE = "listen_config.json"


class MessageListenWindow(QMainWindow):
    def __init__(self, parent=None, wechat=None):
        super().__init__(parent)
        self.setWindowTitle("Message listening configuration management")
        self.resize(1000, 400)  # 宽度加大
        self.wechat = wechat

        # 主容器
        main_widget = QWidget()
        layout = QVBoxLayout(main_widget)

        # --- 表格配置 ---
        self.table = QTableWidget(0, 5)
        self.table.setHorizontalHeaderLabels([
            "监听对象", "对象类型", "消息处理器", "处理器配置", "默认回复消息"
        ])
        layout.addWidget(self.table)

        # --- 按钮区 ---
        btn_layout = QHBoxLayout()

        self.add_btn = QPushButton("新增监听对象")
        self.add_btn.clicked.connect(self.add_row)

        self.del_btn = QPushButton("删除选中行")
        self.del_btn.clicked.connect(self.delete_row)

        self.save_btn = QPushButton("保存配置")
        self.save_btn.clicked.connect(self.save_config)

        self.start_btn = QPushButton("开启监听")
        try:
            self.start_btn.clicked.connect(self.start_message_listen_action)
        except Exception as e:
            print(e)

        btn_layout.addWidget(self.add_btn)
        btn_layout.addWidget(self.del_btn)
        btn_layout.addStretch()
        btn_layout.addWidget(self.save_btn)
        btn_layout.addWidget(self.start_btn)

        layout.addLayout(btn_layout)
        self.setCentralWidget(main_widget)

        # 启动时加载配置
        self.load_config()

    def add_row(self, row_data=None):
        """新增一行"""
        row = self.table.rowCount()
        self.table.insertRow(row)

        # --- 监听对象名称 ---
        name_edit = QLineEdit()
        if row_data:
            name_edit.setText(row_data.get("name", ""))
        self.table.setCellWidget(row, 0, name_edit)

        # --- 对象类型 (群组/好友) ---
        type_combo = QComboBox()
        type_combo.addItems(["群组", "好友"])
        if row_data and row_data.get("object_type") == ListenObjectType.FRIEND:
            type_combo.setCurrentIndex(1)
        self.table.setCellWidget(row, 1, type_combo)

        # --- 消息处理器类型 ---
        process_combo = QComboBox()
        process_combo.addItems(["关键字回复处理器", "AI回复处理器"])
        if row_data and row_data.get("processor_type") == MessageProcessorType.AI:
            process_combo.setCurrentIndex(1)
        self.table.setCellWidget(row, 2, process_combo)

        # --- 处理器配置 (关键字库 or Python 文件路径) ---
        config_edit = QLineEdit()
        if row_data:
            config_edit.setText(row_data.get("processor_config", ""))
        # 根据下拉框动态调整提示
        self.update_processor_config_placeholder(process_combo, config_edit)
        process_combo.currentIndexChanged.connect(
            lambda idx, edit=config_edit, combo=process_combo: self.update_processor_config_placeholder(combo, edit)
        )
        self.table.setCellWidget(row, 3, config_edit)

        # --- 默认回复消息 ---
        reply_edit = QLineEdit()
        if row_data:
            reply_edit.setText(row_data.get("default_reply", ""))
        self.table.setCellWidget(row, 4, reply_edit)

    def update_processor_config_placeholder(self, combo, edit):
        """更新处理器配置输入框提示"""
        if combo.currentIndex() == 0:  # 关键字回复处理器
            edit.setPlaceholderText('请输入关键字回复库(JSON 格式，例如 {"你好": "你好呀"})')
        else:  # AI回复处理器
            edit.setPlaceholderText("请输入 AI 处理器 Python 文件的绝对路径")

    def delete_row(self):
        """删除选中行"""
        selected = self.table.currentRow()
        if selected >= 0:
            self.table.removeRow(selected)

    def save_config(self):
        """保存配置文件"""
        try:
            config = []
            for row in range(self.table.rowCount()):
                name = self.table.cellWidget(row, 0).text().strip()
                type_combo = self.table.cellWidget(row, 1)
                process_combo = self.table.cellWidget(row, 2)
                config_edit = self.table.cellWidget(row, 3).text().strip()
                reply = self.table.cellWidget(row, 4).text().strip()

                if not name:
                    QMessageBox.warning(self, "错误", f"第 {row + 1} 行 '监听对象' 不能为空！")
                    return
                if not config_edit:
                    QMessageBox.warning(self, "错误", f"第 {row + 1} 行 '处理器配置' 不能为空！")
                    return

                object_type = 0 if type_combo.currentIndex() == 0 else 1
                processor_type = 0 if process_combo.currentIndex() == 0 else 1

                # === 校验逻辑 ===
                if processor_type == 0:
                    # 校验是否是合法 JSON
                    try:
                        json.loads(config_edit)
                    except json.JSONDecodeError:
                        QMessageBox.warning(self, "错误", f"第 {row + 1} 行 '处理器配置' 必须是合法 JSON！")
                        return
                elif processor_type == 1:
                    # 校验 Python 文件是否存在
                    if not os.path.isfile(config_edit):
                        QMessageBox.warning(self, "错误", f"第 {row + 1} 行 '处理器配置' 文件不存在: {config_edit}")
                        return

                config.append({
                    "name": name,
                    "object_type": object_type,
                    "processor_type": processor_type,
                    "processor_config": config_edit,
                    "default_reply": reply
                })

            with open(CONFIG_FILE, "w", encoding="utf-8") as f:
                json.dump(config, f, ensure_ascii=False, indent=4)

            QMessageBox.information(self, "提示", "配置已保存成功！")
        except Exception as e:
            QMessageBox.warning(self, "错误", f"保存配置失败: {e}")

    def load_config(self):
        """加载配置文件"""
        if os.path.exists(CONFIG_FILE):
            try:
                with open(CONFIG_FILE, "r", encoding="utf-8") as f:
                    config = json.load(f)

                for row_data in config:
                    row_data["object_type"] = (
                        ListenObjectType.GROUP if row_data.get("object_type", 0) == 0 else ListenObjectType.FRIEND
                    )
                    row_data["processor_type"] = (
                        MessageProcessorType.KEYWORDS if row_data.get("processor_type",
                                                                      0) == 0 else MessageProcessorType.AI
                    )
                    self.add_row(row_data)
            except Exception as e:
                QMessageBox.warning(self, "错误", f"加载配置失败: {e}")

    def start_message_listen_action(self):
        """启动监听（这里只是演示，可以替换为实际逻辑）"""
        configs = []
        for row in range(self.table.rowCount()):
            name = self.table.cellWidget(row, 0).text().strip()
            type_combo = self.table.cellWidget(row, 1)
            process_combo = self.table.cellWidget(row, 2)
            config_edit = self.table.cellWidget(row, 3).text().strip()
            reply = self.table.cellWidget(row, 4).text().strip()

            object_type = ListenObjectType.GROUP
            if type_combo.currentIndex() == 1:
                object_type = ListenObjectType.FRIEND

            processor_type = None
            if process_combo.currentIndex() == 0:
                processor_type = MessageProcessorType.KEYWORDS
                # 将 config_edit 转为字典
                try:
                    config_dict = json.loads(config_edit)  # 把 JSON 字符串转成 dict
                except json.JSONDecodeError as e:
                    QMessageBox.warning(self, "错误", f"第 {row + 1} 行处理器配置不是合法的 JSON 格式: {e}")
                    return
                # 初始化关键字回复字典库
                self.wechat.init_keyword_reply_dbbase(name, config_dict)

            else:
                processor_type = MessageProcessorType.AI
                if not os.path.isfile(config_edit):
                    QMessageBox.warning(self, "错误", f"第 {row + 1} 行 '处理器配置' 文件不存在: {config_edit}")
                    return
                self.wechat.load_custom_ai_reply_interface_by_file_path(name, config_edit)

            self.wechat.add_message_listen_queue(listen_object=name, listen_object_type=object_type,
                                                 message_processor_type=processor_type,
                                                 default_message=reply)
        # 🚀 用后台线程启动整个监听逻辑
        t = threading.Thread(target=self.wechat.start_message_listen, daemon=True)
        QMessageBox.information(self, "开始监听", "正在启动监听，请暂时不要操作鼠标")
        t.start()


# ✅ 程序入口
if __name__ == "__main__":
    import sys

    app = QApplication(sys.argv)
    window = MessageListenWindow()
    window.show()
    sys.exit(app.exec_())
