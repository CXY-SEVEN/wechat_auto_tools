# processors/__init__.py

from .base_message_process import MessageProcessInterface
from .ai_message_process import AIProcess
from .keywords_message_process import KeyWordsProcess

from .base_listen_object_process import ListenObjectProcessInterface
from .friend_object_process import FriendObjectProcess
from .group_object_process import GroupObjectProcess

from .ai_provider_interface import AIProviderInterface


# 对外暴露的接口
__all__ = [
    "MessageProcessInterface",
    "AIProcess",
    "KeyWordsProcess",

    "ListenObjectProcessInterface",
    "FriendObjectProcess",
    "GroupObjectProcess",

    "AIProviderInterface"
]
