from .common_mouse_utils import CommonMouseUtil

# 对外暴露的接口
__all__ = [
    "CommonMouseUtil"
]
